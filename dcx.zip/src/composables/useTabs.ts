// 标签页相关组合式函数
// Tabs Composable

import { ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import type { TabItem } from '@/types/tabs'

/**
 * 标签页相关组合式函数
 * @returns 标签页相关的方法和状态
 */
export function useTabs() {
  const route = useRoute()
  const router = useRouter()

  // 标签页列表
  const tabs = ref<TabItem[]>([])
  // 当前激活的标签页
  const activeTab = ref<string>('')

  /**
   * 添加标签页
   * @param tab 标签页信息
   */
  const addTab = (tab: TabItem) => {
    // 检查标签页是否已存在
    const existingTab = tabs.value.find(t => t.path === tab.path)
    if (!existingTab) {
      tabs.value.push({
        ...tab,
        closable: tab.closable !== false // 默认可关闭
      })
    }
    activeTab.value = tab.path
  }

  /**
   * 移除标签页
   * @param path 标签页路径
   */
  const removeTab = (path: string) => {
    const index = tabs.value.findIndex(t => t.path === path)
    if (index === -1) return

    tabs.value.splice(index, 1)

    // 如果移除的是当前激活的标签页，切换到最后一个标签页
    if (activeTab.value === path) {
      const lastTab = tabs.value[tabs.value.length - 1]
      if (lastTab) {
        activeTab.value = lastTab.path
        router.push(lastTab.path)
      } else {
        // 如果没有标签页了，跳转到首页
        router.push('/user/home')
      }
    }
  }

  /**
   * 清空所有标签页
   */
  const clearTabs = () => {
    tabs.value = []
    activeTab.value = ''
  }

  /**
   * 关闭其他标签页
   * @param path 保留的标签页路径
   */
  const closeOtherTabs = (path: string) => {
    tabs.value = tabs.value.filter(t => t.path === path)
    activeTab.value = path
  }

  /**
   * 关闭所有标签页
   */
  const closeAllTabs = () => {
    clearTabs()
    router.push('/user/home')
  }

  /**
   * 处理标签页点击
   * @param tab 标签页对象
   */
  const handleTabClick = (tab: TabItem) => {
    const targetPath = tab.path as string
    activeTab.value = targetPath
    router.push(targetPath)
  }

  /**
   * 处理标签页移除
   * @param path 标签页路径
   */
  const handleTabRemove = (path: string) => {
    removeTab(path)
  }

  /**
   * 根据路由名称获取标签页标题
   * @param routeName 路由名称
   * @param path 路由路径
   * @returns 标签页标题
   */
  const getTabTitle = (routeName: string | symbol | undefined, path: string): string => {
    if (!routeName || typeof routeName !== 'string') {
      // 根据路径生成标题
      const pathMap: Record<string, string> = {
        '/user': '用户首页',
        '/user/home': '用户首页',
        '/user/info': '学生基本信息',
        '/user/student-basic': '学生基本功展示报名',
        '/user/teacher-basic': '教师基本功展示报名',
        '/user/student-stats': '学生基本功报名信息统计',
        '/user/teacher-stats': '教师基本功报名信息统计',
        '/reviewer/dashboard': '审核首页',
        '/reviewer/approval': '审批中心',
        '/admin/home': '管理员',
        '/logger/home': '日志记录',
      }
      return pathMap[path] || path
    }

    // 根据路由名称映射标题
    const nameMap: Record<string, string> = {
      '首页': '用户首页',
      'user-info': '学生基本信息',
      'user-student-basic': '学生基本功展示报名',
      'user-teacher-basic': '教师基本功展示报名',
      'user-student-stats': '学生基本功报名信息统计',
      'user-teacher-stats': '教师基本功报名信息统计',
      'reviewer-dashboard': '审核首页',
      'reviewer-approval': '审批中心',
      'admin-home': '管理员',
      'logger-home': '日志记录',
    }

    return nameMap[routeName] || routeName
  }

  // 监听路由变化，自动添加标签页
  watch(
    () => route.path,
    (newPath) => {
      if (newPath === '/login' || newPath === '/404' || newPath === '/403') {
        return
      }

      const tabTitle = route.meta?.title as string || getTabTitle(route.name, newPath)
      addTab({
        path: newPath,
        title: tabTitle,
        closable: true
      })
    },
    { immediate: true }
  )

  return {
    // 状态
    tabs,
    activeTab,

    // 方法
    addTab,
    removeTab,
    clearTabs,
    closeOtherTabs,
    closeAllTabs,
    handleTabClick,
    handleTabRemove
  }
}

<template>
  <div>
    <h1>管理员端首页</h1>
    <p>这是管理员端的首页，可以管理系统等。</p>
  </div>
</template>

<script lang="ts" setup name="AdminHomePage">
</script>

<style lang="scss" scoped>
</style>


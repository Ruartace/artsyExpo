export interface HttpResponse<T> { code: number; message: string; data: T }

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export async function httpGet<T>(url: string, params?: Record<string, unknown>): Promise<HttpResponse<T>> {
	// 简易 mock：真实项目中替换为 fetch/axios
	return { code: 0, message: 'ok', data: ({} as unknown) as T }
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export async function httpPost<T>(url: string, body?: unknown): Promise<HttpResponse<T>> {
	return { code: 0, message: 'ok', data: ({} as unknown) as T }
}


